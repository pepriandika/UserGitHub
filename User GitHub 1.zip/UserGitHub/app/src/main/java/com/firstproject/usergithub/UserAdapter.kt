package com.firstproject.usergithub

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CircleCrop

class UserAdapter(private val listUser: List<UserResponse>) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        var tvItem: TextView = view.findViewById(R.id.tvItemName)
        var imgPhoto: ImageView = view.findViewById(R.id.img_item_photo)
        var detailButton: Button = view.findViewById(R.id.materialButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
       return ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.user_card_view, parent, false))
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val user = listUser[position]
        holder.tvItem.text = user.login.toString()
        Glide.with(holder.itemView.context)
            .load("https://avatars.githubusercontent.com/u/${user.id}")
            .transform(CircleCrop())
            .into(holder.imgPhoto)
        holder.detailButton.setOnClickListener {
            val intent = Intent(holder.itemView.context, DetailActivity::class.java)
            intent.putExtra("userName", user.login)
            intent.putExtra("userId", user.id)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return listUser.size
    }
}