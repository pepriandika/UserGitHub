package com.firstproject.usergithub


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.firstproject.usergithub.databinding.FragmentFollowingBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



class FollowingFragment : Fragment() {
    private lateinit  var login: String

    private lateinit var binding: FragmentFollowingBinding

    companion object {
        private const val TAG = "Following Fragment"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentFollowingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val layoutManager = LinearLayoutManager(requireContext())
        binding.rvUserListFollowing.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(requireContext(), layoutManager.orientation)
        binding.rvUserListFollowing.addItemDecoration(itemDecoration)

        arguments?.let {
            login = it.getString("login").toString()
            daftarUser(login)
        }

    }

    private fun daftarUser(login:String) {
        showLoading(true)
        val client = ApiConfig.getApiService().getFollowing(login)
        client.enqueue(object : Callback<List<UserResponse>> {
            override fun onResponse(
                call: Call<List<UserResponse>>,
                response: Response<List<UserResponse>>
            ) {
                showLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        setUserData(responseBody)
                    }
                } else {

                }
            }

            override fun onFailure(call: Call<List<UserResponse>>, t: Throwable) {
                showLoading(false)
            }

        })
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar4.visibility = View.VISIBLE
        } else {
            binding.progressBar4.visibility = View.GONE
        }
    }

    private fun setUserData(userResponse: List<UserResponse>) {
        val userList = ArrayList<UserResponse>()
        for (i in userResponse) {
            val user = UserResponse(
                i.followingUrl,
                i.login,
                i.id,
                i.followersUrl,
                i.avatarUrl,
                i.followers,
                i.following,
                i.name
            )
            userList.add(user)
        }
        val adapter = UserAdapter(userList)
        binding.rvUserListFollowing.adapter = adapter
    }
}


